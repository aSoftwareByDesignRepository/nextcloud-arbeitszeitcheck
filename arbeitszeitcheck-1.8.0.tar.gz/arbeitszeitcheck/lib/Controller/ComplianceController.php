<?php

declare(strict_types=1);

/**
 * Compliance controller for the arbeitszeitcheck app
 *
 * @copyright Copyright (c) 2024, Nextcloud GmbH
 * @license AGPL-3.0-or-later
 */

namespace OCA\ArbeitszeitCheck\Controller;

use OCA\ArbeitszeitCheck\Service\ComplianceService;
use OCA\ArbeitszeitCheck\Service\CSPService;
use OCA\ArbeitszeitCheck\Service\PermissionService;
use OCA\ArbeitszeitCheck\Service\LocaleFormatService;
use OCA\ArbeitszeitCheck\Service\NavigationFlagsService;
use OCA\ArbeitszeitCheck\Support\LaborLawProfileFactory;
use OCA\ArbeitszeitCheck\Support\RegionRegistry;
use OCA\ArbeitszeitCheck\Db\AuditLogMapper;
use OCA\ArbeitszeitCheck\Db\ComplianceViolationMapper;
use OCA\ArbeitszeitCheck\Db\ComplianceViolation;
use OCA\ArbeitszeitCheck\Constants;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\AppFramework\Http\JSONResponse;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\IRequest;
use OCP\IURLGenerator;
use OCP\IUserManager;
use OCP\IUserSession;
use OCP\IL10N;
use OCP\Util;

/**
 * ComplianceController
 */
class ComplianceController extends Controller
{
	use CSPTrait;
	use NavigationFlagsTrait;
	use PageShellTrait;

	private ComplianceService $complianceService;
	private ComplianceViolationMapper $violationMapper;
	private AuditLogMapper $auditLogMapper;
	protected PermissionService $permissionService;
	protected IUserSession $userSession;
	private IUserManager $userManager;
	protected IURLGenerator $urlGenerator;
	protected IL10N $l10n;
	protected LocaleFormatService $localeFormat;
	protected NavigationFlagsService $navigationFlags;
	private LaborLawProfileFactory $laborLawProfileFactory;

	public function __construct(
		string $appName,
		IRequest $request,
		ComplianceService $complianceService,
		ComplianceViolationMapper $violationMapper,
		AuditLogMapper $auditLogMapper,
		PermissionService $permissionService,
		IUserSession $userSession,
		IUserManager $userManager,
		IURLGenerator $urlGenerator,
		CSPService $cspService,
		LocaleFormatService $localeFormat,
		IL10N $l10n,
		NavigationFlagsService $navigationFlags,
		LaborLawProfileFactory $laborLawProfileFactory,
	) {
		parent::__construct($appName, $request);
		$this->complianceService = $complianceService;
		$this->violationMapper = $violationMapper;
		$this->auditLogMapper = $auditLogMapper;
		$this->permissionService = $permissionService;
		$this->userSession = $userSession;
		$this->userManager = $userManager;
		$this->urlGenerator = $urlGenerator;
		$this->localeFormat = $localeFormat;
		$this->l10n = $l10n;
		$this->navigationFlags = $navigationFlags;
		$this->laborLawProfileFactory = $laborLawProfileFactory;
		$this->setCspService($cspService);
	}

	/**
	 * Country-aware lead copy for the compliance dashboard (DE ArbZG / AT AZG / CH ArG).
	 * Uses the viewing user's effective labour-law country (E-9), not only the
	 * organisation default — otherwise a DE-instance user with AT override still
	 * sees the German lead while compliance checks already follow AZG.
	 */
	private function complianceDashboardLead(?string $userId = null): string
	{
		$country = $userId !== null && $userId !== ''
			? $this->laborLawProfileFactory->getEffectiveCountry($userId)
			: $this->laborLawProfileFactory->getConfiguredCountry();
		return match ($country) {
			RegionRegistry::COUNTRY_AT => $this->l10n->t('Check if your working time follows Austrian labour law and see any problems that need fixing'),
			RegionRegistry::COUNTRY_CH => $this->l10n->t('Check if your working time follows Swiss labour law and see any problems that need fixing'),
			default => $this->l10n->t('Check if your working time follows German labor law and see any problems that need fixing'),
		};
	}

	/**
	 * Compliance pages hide substitution-requests nav even when pending items exist.
	 *
	 * @return array{
	 *   showSubstitutionLink: bool,
	 *   showManagerLink: bool,
	 *   showReportsLink: bool,
	 *   showAdminNav: bool,
	 *   monthClosureEnabled: bool
	 * }
	 */
	protected function getNavigationFlags(string $userId): array
	{
		return $this->navigationFlags->forComplianceUser($userId);
	}

	/**
	 * Ensure current user may access compliance data for the given target user.
	 * Allowed: own user, team members (manager), or admin.
	 */
	private function ensureCanAccessUserCompliance(string $currentUserId, string $targetUserId): void
	{
		if ($this->permissionService->canViewUserCompliance($currentUserId, $targetUserId)) {
			return;
		}
		$this->permissionService->logPermissionDenied($currentUserId, 'view_compliance', 'compliance', $targetUserId);
		throw new \Exception($this->l10n->t('Access denied. You can only view compliance data for yourself or your team members.'));
	}

	/**
	 * Get current user ID
	 *
	 * @return string
	 */
	private function getUserId(): string
	{
		$user = $this->userSession->getUser();
		if (!$user) {
			throw new \Exception('User not authenticated');
		}
		return $user->getUID();
	}

	/**
	 * Compliance dashboard page
	 *
	 */
	#[NoAdminRequired]
	#[NoCSRFRequired]
	public function dashboard(): TemplateResponse
	{
		$this->registerFrontEndAssets('compliance-dashboard', 'compliance-violations', ['compliance-violations']);

		try {
			$userId = $this->getUserId();

			// Get compliance status
			$complianceStatus = $this->complianceService->getComplianceStatus($userId);

			// Get recent violations
			$recentViolations = $this->violationMapper->findByUser($userId, null, 10, 0);
			$violationsData = [];
			foreach ($recentViolations as $violation) {
				$date = $violation->getDate();
				$violationsData[] = [
					'id' => $violation->getId(),
					'type' => $violation->getViolationType(),
					'severity' => $violation->getSeverity(),
					// Human-readable, localized date for dashboard display (DD.MM.YYYY)
					'date' => $date ? $date->format('d.m.Y') : null,
					// Machine-friendly ISO date for charts / sorting
					'dateIso' => $date ? $date->format('Y-m-d') : null,
					'resolved' => $violation->getResolved(),
					'description' => $violation->getDescription()
				];
			}

			$navFlags = $this->getNavigationFlags($userId);

			$response = new TemplateResponse('arbeitszeitcheck', 'compliance-dashboard', $this->buildShellParams(
				'compliance',
				$this->l10n->t('Compliance Dashboard'),
				$this->complianceDashboardLead($userId),
				$navFlags,
			) + [
				'complianceStatus' => $complianceStatus,
				'recentViolations' => $violationsData,
				'showComplianceRunCheck' => $this->permissionService->isAdmin($userId),
				'complianceRunCheckUrl' => $this->urlGenerator->linkToRoute('arbeitszeitcheck.compliance.runCheck'),
				'complianceViolationsUrl' => $this->urlGenerator->linkToRoute('arbeitszeitcheck.compliance.violations'),
			]);
			return $this->configureCSP($response);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Compliance dashboard error: ' . $e->getMessage(), ['exception' => $e]);
			$navFlags = $this->getNavigationFlagsForSession();
			$leadUserId = null;
			try {
				$leadUserId = $this->getUserId();
			} catch (\Throwable) {
				$leadUserId = null;
			}
			$response = new TemplateResponse('arbeitszeitcheck', 'compliance-dashboard', $this->buildShellParams(
				'compliance',
				$this->l10n->t('Compliance Dashboard'),
				$this->complianceDashboardLead($leadUserId),
				$navFlags,
			) + [
				'complianceStatus' => [
					'compliant' => false,
					'score' => 0,
					'has_data' => false,
					'load_error' => true,
				],
				'recentViolations' => [],
				'error' => $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.'),
			]);
			return $this->configureCSP($response);
		}
	}

	/**
	 * Get violations page
	 *
	 */
	#[NoAdminRequired]
	#[NoCSRFRequired]
	public function violations(): TemplateResponse
	{
		$this->registerFrontEndAssets('compliance-violations', 'compliance-violations');
		Util::addScript('arbeitszeitcheck', 'common/datepicker');

		try {
			$currentUserId = $this->getUserId();
			$filterUserId = trim((string)($this->request->getParam('userId') ?? ''));
			$targetUserId = $currentUserId;
			$filterDisplayName = null;
			if ($filterUserId !== '' && $filterUserId !== $currentUserId) {
				$this->ensureCanAccessUserCompliance($currentUserId, $filterUserId);
				$targetUserId = $filterUserId;
				$user = $this->userManager->get($filterUserId);
				$filterDisplayName = $user ? $user->getDisplayName() : $filterUserId;
			}

			// Initial view; filters and date range are handled via the API (getViolations).
			$violations = $this->violationMapper->findByUser($targetUserId, null);
			$violations = array_slice($violations, 0, 50);

			$violationsData = [];
			foreach ($violations as $violation) {
				$violationsData[] = [
					'id' => $violation->getId(),
					'type' => $violation->getViolationType(),
					'severity' => $violation->getSeverity(),
					'date' => $violation->getDate() ? $violation->getDate()->format('Y-m-d') : null,
					'resolved' => $violation->getResolved(),
					'description' => $violation->getDescription(),
					'can_resolve' => !$violation->getResolved()
						&& $this->permissionService->canResolveViolation($currentUserId, $violation->getUserId()),
				];
			}

			$navFlags = $this->getNavigationFlags($currentUserId);

			$response = new TemplateResponse('arbeitszeitcheck', 'compliance-violations', $this->buildShellParams(
				'compliance-violations',
				$this->l10n->t('Compliance Violations'),
				$this->l10n->t('Review and resolve working time rule violations'),
				$navFlags,
			) + [
				'violations' => $violationsData,
				'total' => count($violations),
				'filterUserId' => $filterUserId !== '' && $filterUserId !== $currentUserId ? $filterUserId : null,
				'filterDisplayName' => $filterDisplayName,
			]);
			return $this->configureCSP($response);
		} catch (\Throwable $e) {
			$navFlags = $this->getNavigationFlagsForSession();
			$response = new TemplateResponse('arbeitszeitcheck', 'compliance-violations', $this->buildShellParams(
				'compliance-violations',
				$this->l10n->t('Compliance Violations'),
				$this->l10n->t('Review and resolve working time rule violations'),
				$navFlags,
			) + [
				'violations' => [],
				'total' => 0,
				'error' => $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.'),
			]);
			return $this->configureCSP($response);
		}
	}

	/**
	 * Compliance reports page
	 *
	 */
	#[NoAdminRequired]
	#[NoCSRFRequired]
	public function reports(): TemplateResponse
	{
		$this->registerFrontEndAssets('compliance-reports');

		try {
			$userId = $this->getUserId();

			// Get compliance summary for all recorded violations
			$violations = $this->violationMapper->findByUser($userId, null);

			$reportData = [
				'total_violations' => count($violations),
				'unresolved' => 0,
				'by_type' => [],
				'by_severity' => []
			];

			foreach ($violations as $violation) {
				if (!$violation->getResolved()) {
					$reportData['unresolved']++;
				}

				$type = $violation->getViolationType();
				$reportData['by_type'][$type] = ($reportData['by_type'][$type] ?? 0) + 1;

				$severity = $violation->getSeverity();
				$reportData['by_severity'][$severity] = ($reportData['by_severity'][$severity] ?? 0) + 1;
			}

			$navFlags = $this->getNavigationFlags($userId);

			$response = new TemplateResponse(
				'arbeitszeitcheck',
				'compliance-reports',
				$this->buildShellParams(
					'compliance-reports',
					$this->l10n->t('Compliance Reports'),
					$this->l10n->t('Summary of compliance violations and trends'),
					$navFlags,
				) + [
					'reportData' => $reportData,
					'startDate' => null,
					'endDate' => null,
				]
			);
			return $this->configureCSP($response);
		} catch (\Throwable $e) {
			$navFlags = $this->getNavigationFlagsForSession();
			$response = new TemplateResponse('arbeitszeitcheck', 'compliance-reports', $this->buildShellParams(
				'compliance-reports',
				$this->l10n->t('Compliance Reports'),
				$this->l10n->t('Summary of compliance violations and trends'),
				$navFlags,
			) + [
				'reportData' => [
					'total_violations' => 0,
					'unresolved' => 0,
					'by_type' => [],
					'by_severity' => []
				],
				'startDate' => date('Y-m-d', strtotime('-30 days')),
				'endDate' => date('Y-m-d'),
				'error' => $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.'),
			]);
			return $this->configureCSP($response);
		}
	}

	/**
	 * Parse and validate date string (Y-m-d format). Returns null for empty, throws on invalid.
	 *
	 * @param string|null $dateStr Date string in Y-m-d format
	 * @param string $paramName Parameter name for error message
	 * @return \DateTime|null Parsed DateTime or null if empty
	 * @throws \Exception On invalid date format
	 */
	private function parseDateParam(?string $dateStr, string $paramName = 'date'): ?\DateTime
	{
		if ($dateStr === null || $dateStr === '') {
			return null;
		}
		$d = \DateTime::createFromFormat('Y-m-d', $dateStr);
		if ($d === false || $d->format('Y-m-d') !== $dateStr) {
			throw new \Exception($this->l10n->t('Invalid %s format. Use Y-m-d (e.g. 2024-01-15)', [$paramName]));
		}
		return $d;
	}

	private function parseIsoDateTimeParam(string $value, string $paramName): \DateTime
	{
		$formats = [
			\DateTime::ATOM,
			'Y-m-d\TH:i:s.u\Z',
			'Y-m-d\TH:i:s\Z',
			'Y-m-d\TH:i:sP',
		];
		foreach ($formats as $format) {
			$parsed = \DateTime::createFromFormat($format, $value);
			if ($parsed !== false) {
				return $parsed;
			}
		}

		throw new \InvalidArgumentException($this->l10n->t(
			'Invalid %s format. Use ISO-8601 (e.g. 2024-01-15T09:00:00Z).',
			[$paramName]
		));
	}

	private function normalizeLimit(?int $limit): int
	{
		$value = $limit ?? Constants::DEFAULT_LIST_LIMIT;
		if ($value < 1) {
			return Constants::DEFAULT_LIST_LIMIT;
		}
		return min($value, Constants::MAX_LIST_LIMIT);
	}

	private function normalizeOffset(?int $offset): int
	{
		return max(0, (int)($offset ?? 0));
	}

	/**
	 * Get compliance violations API endpoint
	 *
	 * @param string|null $userId Filter by user ID (admin only)
	 * @param string|null $violationType Filter by violation type
	 * @param bool|null $resolved Filter by resolved status
	 * @param string|null $severity Filter by severity
	 * @param string|null $startDate Start date filter (Y-m-d format)
	 * @param string|null $endDate End date filter (Y-m-d format)
	 * @param int|null $limit Pagination limit
	 * @param int|null $offset Pagination offset
	 * @return JSONResponse
	 */
	#[NoAdminRequired]
	public function getViolations(
		?string $userId = null,
		?string $violationType = null,
		?bool $resolved = null,
		?string $severity = null,
		?string $startDate = null,
		?string $endDate = null,
		?int $limit = Constants::DEFAULT_LIST_LIMIT,
		?int $offset = 0
	): JSONResponse {
		try {
			$currentUserId = $this->getUserId();
			$targetUserId = $userId ?? $currentUserId;
			$this->ensureCanAccessUserCompliance($currentUserId, $targetUserId);
			$limit = $this->normalizeLimit($limit);
			$offset = $this->normalizeOffset($offset);

			// Parse and validate date params (Y-m-d format)
			$startDt = $this->parseDateParam($startDate, 'start_date');
			$endDt = $this->parseDateParam($endDate, 'end_date');

			// Build filters
			$filters = [];
			if ($startDt) {
				$filters['start_date'] = $startDt;
			}
			if ($endDt) {
				$endDateTime = clone $endDt;
				$endDateTime->setTime(23, 59, 59);
				$endDateTime->modify('+1 day'); // Make exclusive for date range query
				$filters['end_date'] = $endDateTime;
			}

			// Get violations using mapper methods
			if ($startDt || $endDt) {
				$start = $startDt ?: new \DateTime('1970-01-01');
				$start->setTime(0, 0, 0);
				$end = $endDt ? clone $endDt : new \DateTime('2099-12-31');
				$end->setTime(0, 0, 0);
				$end->modify('+1 day'); // Exclusive upper bound: next day midnight
				$allViolations = $this->violationMapper->findByDateRange($start, $end, $targetUserId, $resolved);
			} else {
				$allViolations = $this->violationMapper->findByUser($targetUserId, $resolved);
			}

			// Apply additional filters in PHP (violation type, severity)
			if ($violationType) {
				$allViolations = array_filter($allViolations, function ($violation) use ($violationType) {
					return $violation->getViolationType() === $violationType;
				});
			}

			if ($severity) {
				$allViolations = array_filter($allViolations, function ($violation) use ($severity) {
					return $violation->getSeverity() === $severity;
				});
			}

			// Get total count for pagination (after filtering)
			$totalCount = count($allViolations);

			// Re-index array after filtering
			$allViolations = array_values($allViolations);

			// Apply pagination
			$violations = array_slice($allViolations, $offset, $limit);

			// Safely map violations to summaries
			$violationSummaries = [];
			foreach ($violations as $violation) {
				try {
					$summary = $violation->getSummary();
					$summary['type'] = $summary['violationType'] ?? $violation->getViolationType();
					$summary['can_resolve'] = !$violation->getResolved()
						&& $this->permissionService->canResolveViolation($currentUserId, $violation->getUserId());
					$violationSummaries[] = $summary;
				} catch (\Throwable $e) {
					\OCP\Log\logger('arbeitszeitcheck')->error('Error getting summary for violation ' . $violation->getId() . ': ' . $e->getMessage(), ["exception" => $e]);
					continue;
				}
			}

			return new JSONResponse([
				'success' => true,
				'violations' => $violationSummaries,
				'total' => $totalCount
			]);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Error in ComplianceController: ' . $e->getMessage(), ["exception" => $e]);
			$raw = $e->getMessage();
			if (strpos($raw, 'User not authenticated') !== false) {
				$errorMessage = $this->l10n->t('User not authenticated');
				$status = Http::STATUS_UNAUTHORIZED;
			} elseif (strpos($raw, 'Access denied') !== false) {
				$errorMessage = $this->l10n->t('Access denied');
				$status = Http::STATUS_FORBIDDEN;
			} else {
				$errorMessage = $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.');
				$status = Http::STATUS_BAD_REQUEST;
			}
			return new JSONResponse([
				'success' => false,
				'error' => $errorMessage
			], $status);
		}
	}

	/**
	 * Get single violation by ID
	 *
	 * @param int $id Violation ID
	 * @return JSONResponse
	 */
	#[NoAdminRequired]
	public function getViolation(int $id): JSONResponse
	{
		try {
			$currentUserId = $this->getUserId();
			$violation = $this->violationMapper->find($id);
			$violationOwnerId = $violation->getUserId();

			// Allow: owner, admin, or manager of the violation owner
			if (!$this->permissionService->canViewUserCompliance($currentUserId, $violationOwnerId)) {
				$this->permissionService->logPermissionDenied($currentUserId, 'get_violation', 'compliance_violation', (string) $id);
				return new JSONResponse([
					'success' => false,
					'error' => $this->l10n->t('Violation not found')
				], Http::STATUS_NOT_FOUND);
			}

			return new JSONResponse([
				'success' => true,
				'violation' => $violation->getSummary()
			]);
		} catch (\OCP\AppFramework\Db\DoesNotExistException $e) {
			return new JSONResponse([
				'success' => false,
				'error' => $this->l10n->t('Violation not found')
			], Http::STATUS_NOT_FOUND);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Error in ComplianceController: ' . $e->getMessage(), ["exception" => $e]);
			$raw = $e->getMessage();
			$isUnauthenticated = strpos($raw, 'User not authenticated') !== false;
			$errorMessage = $isUnauthenticated
				? $this->l10n->t('User not authenticated')
				: $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.');
			return new JSONResponse([
				'success' => false,
				'error' => $errorMessage
			], $isUnauthenticated ? Http::STATUS_UNAUTHORIZED : Http::STATUS_BAD_REQUEST);
		}
	}

	/**
	 * Resolve a violation
	 *
	 * @param int $id Violation ID
	 * @return JSONResponse
	 */
	#[NoAdminRequired]
	public function resolveViolation(int $id): JSONResponse
	{
		try {
			$userId = $this->getUserId();
			$violation = $this->violationMapper->find($id);
			$violationOwnerId = $violation->getUserId();

			// Admin or manager for the violation owner may resolve (owner cannot resolve own)
			if (!$this->permissionService->canResolveViolation($userId, $violationOwnerId)) {
				$this->permissionService->logPermissionDenied($userId, 'resolve_violation', 'compliance_violation', (string) $id);
				return new JSONResponse([
					'success' => false,
					'error' => $this->l10n->t('Violation not found')
				], Http::STATUS_NOT_FOUND);
			}

			if ($violation->getResolved()) {
				return new JSONResponse([
					'success' => false,
					'error' => $this->l10n->t('Violation is already resolved')
				], Http::STATUS_BAD_REQUEST);
			}

			$oldValues = $violation->getSummary();

			$updatedViolation = $this->violationMapper->resolveViolation($id, $userId);

			$newValues = $updatedViolation->getSummary();
			$this->auditLogMapper->logAction(
				$violationOwnerId,
				'compliance_violation_resolved',
				'compliance_violation',
				$id,
				$oldValues,
				$newValues,
				$userId
			);

			return new JSONResponse([
				'success' => true,
				'violation' => $updatedViolation->getSummary()
			]);
		} catch (\OCP\AppFramework\Db\DoesNotExistException $e) {
			return new JSONResponse([
				'success' => false,
				'error' => $this->l10n->t('Violation not found')
			], Http::STATUS_NOT_FOUND);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Error in ComplianceController: ' . $e->getMessage(), ["exception" => $e]);
			$raw = $e->getMessage();
			$errorMessage = strpos($raw, 'User not authenticated') !== false
				? $this->l10n->t('User not authenticated')
				: $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.');
			return new JSONResponse([
				'success' => false,
				'error' => $errorMessage
			], Http::STATUS_BAD_REQUEST);
		}
	}

	/**
	 * Get compliance status for current user
	 *
	 * @return JSONResponse
	 */
	#[NoAdminRequired]
	public function getStatus(): JSONResponse
	{
		try {
			$userId = $this->getUserId();
			$status = $this->complianceService->getComplianceStatus($userId);

			return new JSONResponse([
				'success' => true,
				'status' => $status
			]);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Error in ComplianceController: ' . $e->getMessage(), ["exception" => $e]);
			// Check if it's an authentication error
			$raw = $e->getMessage();
			$isUnauthenticated = strpos($raw, 'User not authenticated') !== false;
			$errorMessage = $isUnauthenticated
				? $this->l10n->t('User not authenticated')
				: $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.');
			return new JSONResponse([
				'success' => false,
				'error' => $errorMessage
			], $isUnauthenticated ? Http::STATUS_UNAUTHORIZED : Http::STATUS_BAD_REQUEST);
		}
	}

	/**
	 * Generate compliance report
	 *
	 * @param string|null $startDate Start date (Y-m-d format)
	 * @param string|null $endDate End date (Y-m-d format)
	 * @param string|null $userId When set to an empty string (`userId=`) and the caller is an admin,
	 *                            the report is generated for all enabled users. Otherwise, generates for that user.
	 * @return JSONResponse
	 */
	#[NoAdminRequired]
	public function getReport(?string $startDate = null, ?string $endDate = null, ?string $userId = null): JSONResponse
	{
		try {
			$currentUserId = $this->getUserId();
			$targetUserId = null;

			// Special case: organization scope for admins is expressed as an empty string (`userId=`).
			// We treat `userId=""` as "all users" and require admin privileges.
			if ($userId === '') {
				if (!$this->permissionService->isAdmin($currentUserId)) {
					throw new \Exception($this->l10n->t('Access denied. You can only view compliance data for yourself or your team members.'));
				}
				$targetUserId = null;
			} else {
				// Default: current user (or an explicitly provided userId if a legacy caller passes it).
				$targetUserId = $userId ?? $currentUserId;
				$this->ensureCanAccessUserCompliance($currentUserId, $targetUserId);
			}

			// Parse and validate date params (Y-m-d format)
			$startDt = $this->parseDateParam($startDate, 'start_date');
			$endDt = $this->parseDateParam($endDate, 'end_date');

			// Default to last 30 days if not specified
			$end = $endDt ?: new \DateTime();
			$end->setTime(23, 59, 59);
			$start = $startDt ?: clone $end;
			if (!$startDt) {
				$start->modify('-30 days');
			}
			$start->setTime(0, 0, 0);
			if ($start > $end) {
				throw new \Exception($this->l10n->t('Start date must be before or equal to end date'));
			}
			$days = (int)$end->diff($start)->format('%a');
			if ($days > Constants::MAX_EXPORT_DATE_RANGE_DAYS) {
				throw new \Exception($this->l10n->t(
					'Export date range must not exceed %d days. Please narrow the range.',
					[Constants::MAX_EXPORT_DATE_RANGE_DAYS]
				));
			}

			$report = $this->complianceService->generateComplianceReport($start, $end, $targetUserId);

			return new JSONResponse([
				'success' => true,
				'report' => $report
			]);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Error in ComplianceController: ' . $e->getMessage(), ["exception" => $e]);
			// Check if it's an authentication error
			$raw = $e->getMessage();
			$isUnauthenticated = strpos($raw, 'User not authenticated') !== false;
			$errorMessage = $isUnauthenticated
				? $this->l10n->t('User not authenticated')
				: $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.');
			return new JSONResponse([
				'success' => false,
				'error' => $errorMessage
			], $isUnauthenticated ? Http::STATUS_UNAUTHORIZED : Http::STATUS_BAD_REQUEST);
		}
	}

	/**
	 * Check whether the minimum rest period (ArbZG §5) is met for a given start time.
	 *
	 * Used by the frontend validation layer to give real-time feedback before the user
	 * saves a new time entry. The authenticated user's ID is always used — the optional
	 * `userId` query parameter from legacy JS callers is intentionally ignored to prevent
	 * checking another user's rest period.
	 *
	 * @param string $startTime ISO-8601 start time of the new entry
	 * @param int|null $excludeEntryId Entry ID to exclude from the check (when editing)
	 * @return JSONResponse
	 */
	#[NoAdminRequired]
	#[NoCSRFRequired]
	public function checkRestPeriod(string $startTime, ?int $excludeEntryId = null): JSONResponse
	{
		try {
			$userId = $this->getUserId();

			$startDt = $this->parseIsoDateTimeParam($startTime, 'start_time');

			$result = $this->complianceService->checkRestPeriodForStartTime($userId, $startDt, $excludeEntryId);

			return new JSONResponse([
				'success' => true,
				'valid' => $result['valid'],
				'message' => $result['message'] ?? null,
				'earliestStartTime' => isset($result['earliestStartTime'])
					? $result['earliestStartTime']->format(\DateTime::ATOM)
					: null,
			]);
		} catch (\InvalidArgumentException $e) {
			return new JSONResponse([
				'success' => false,
				'error' => $e->getMessage()
			], Http::STATUS_BAD_REQUEST);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('checkRestPeriod error: ' . $e->getMessage(), ['exception' => $e]);
			return new JSONResponse([
				'success' => false,
				'error' => $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.')
			], Http::STATUS_INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Manually trigger compliance check (admin only)
	 *
	 * @return JSONResponse
	 */
	#[NoAdminRequired]
	public function runCheck(): JSONResponse
	{
		try {
			// Only admins can manually trigger compliance checks
			$user = $this->userSession->getUser();
			if (!$user || !$this->permissionService->isAdmin($user->getUID())) {
				return new JSONResponse([
					'success' => false,
					'error' => $this->l10n->t('Admin access required')
				], Http::STATUS_FORBIDDEN);
			}

			// Run compliance check for all users
			$stats = $this->complianceService->runDailyComplianceCheck();

			return new JSONResponse([
				'success' => true,
				'message' => $this->l10n->t('Compliance check completed successfully'),
				'stats' => $stats
			]);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Error in ComplianceController: ' . $e->getMessage(), ["exception" => $e]);
			// Check if it's an authentication error
			$raw = $e->getMessage();
			$errorMessage = strpos($raw, 'User not authenticated') !== false
				? $this->l10n->t('User not authenticated')
				: $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.');
			return new JSONResponse([
				'success' => false,
				'error' => $errorMessage
			], Http::STATUS_BAD_REQUEST);
		}
	}
}
