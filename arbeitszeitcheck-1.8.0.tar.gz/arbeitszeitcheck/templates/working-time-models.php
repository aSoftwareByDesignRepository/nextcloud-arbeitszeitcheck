<?php

declare(strict_types=1);

/**
 * Working time models template for arbeitszeitcheck app
 *
 * @copyright Copyright (c) 2024, Nextcloud GmbH
 * @license AGPL-3.0-or-later
 */


/** @var array $_ */
/** @var \OCP\IL10N $l */
$l = $_['l'] ?? \OCP\Util::getL10N('arbeitszeitcheck');

$models = $_['models'] ?? [];
?>

<?php include __DIR__ . '/common/page-start.php'; ?>


        <div class="azc-page-stack">

        <section id="wtm-editor-panel"
                 class="azc-card wtm-editor-panel"
                 hidden
                 aria-labelledby="wtm-editor-heading"></section>

        <section class="azc-card working-time-models-card" aria-labelledby="working-time-models-heading">
            <header class="azc-card__header">
                <div class="azc-card__header-text">
                    <h2 id="working-time-models-heading" class="azc-card__title"><?php p($l->t('Working time models')); ?></h2>
                    <p class="azc-card__lead"><?php p($l->t('Work schedules you can assign to employees, e.g. full-time (8 hours/day) or part-time (4 hours/day).')); ?></p>
                </div>
                <div class="azc-card__header-actions">
                    <button type="button"
                            id="create-model"
                            class="azc-btn azc-btn--primary"
                            aria-label="<?php p($l->t('Create new working time model')); ?>"
                            title="<?php p($l->t('Create a new working time model, e.g., full-time (8 hours/day) or part-time (4 hours/day).')); ?>">
                        <?php p($l->t('New working time model')); ?>
                    </button>
                </div>
            </header>
            <div class="azc-card__body">
            <!-- Models Table -->
            <div class="table-container" tabindex="0" role="region" aria-label="<?php p($l->t('Working time models')); ?>">
                <table class="table table--hover azc-table--responsive" id="models-table" role="table" aria-label="<?php p($l->t('Working time models')); ?>">
                <thead>
                    <tr>
                        <th scope="col"><?php p($l->t('Name')); ?></th>
                        <th scope="col"><?php p($l->t('Type')); ?></th>
                        <th scope="col"><?php p($l->t('Weekly hours')); ?></th>
                        <th scope="col"><?php p($l->t('Daily hours')); ?></th>
                        <th scope="col"><?php p($l->t('Work days/week')); ?></th>
                        <th scope="col"><?php p($l->t('Default')); ?></th>
                        <th scope="col" class="azc-table-actions-col"><?php p($l->t('Actions')); ?></th>
                    </tr>
                </thead>
                <tbody id="models-tbody">
                    <?php if (empty($models)): ?>
                        <tr>
                            <td colspan="7" class="text-center">
                                <?php p($l->t('No working time models available')); ?>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach (($models ?? []) as $model): ?>
                            <tr data-model-id="<?php p($model['id']); ?>">
                                <td data-label="<?php p($l->t('Name')); ?>"><?php p($model['name']); ?></td>
                                <td data-label="<?php p($l->t('Type')); ?>">
                                    <?php
                                    $typeKey = $model['type'] ?? '';
                                    $typeLabel = match ($typeKey) {
                                        \OCA\ArbeitszeitCheck\Db\WorkingTimeModel::TYPE_FULL_TIME => $l->t('Full-time'),
                                        \OCA\ArbeitszeitCheck\Db\WorkingTimeModel::TYPE_PART_TIME => $l->t('Part-time'),
                                        \OCA\ArbeitszeitCheck\Db\WorkingTimeModel::TYPE_FLEXIBLE => $l->t('Flexible'),
                                        \OCA\ArbeitszeitCheck\Db\WorkingTimeModel::TYPE_TRUST_BASED => $l->t('Trust-based'),
                                        \OCA\ArbeitszeitCheck\Db\WorkingTimeModel::TYPE_SHIFT_WORK => $l->t('Shift work'),
                                        default => $typeKey,
                                    };
                                    p($typeLabel);
                                    ?>
                                </td>
                                <td data-label="<?php p($l->t('Weekly hours')); ?>"><?php p($model['weeklyHours']); ?>h</td>
                                <td data-label="<?php p($l->t('Daily hours')); ?>"><?php p($model['dailyHours']); ?>h</td>
                                <td data-label="<?php p($l->t('Work days/week')); ?>"><?php p((string)($model['workDaysPerWeek'] ?? 5)); ?></td>
                                <td data-label="<?php p($l->t('Default')); ?>">
                                    <?php if ($model['isDefault']): ?>
                                        <span class="badge badge--success"><?php p($l->t('Yes')); ?></span>
                                    <?php else: ?>
                                        <span class="badge"><?php p($l->t('No')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="actions-cell" data-label="<?php p($l->t('Actions')); ?>">
                                    <div class="azc-table-actions" role="group" aria-label="<?php p($l->t('Actions')); ?>">
                                    <button type="button"
                                            class="btn btn--sm btn--secondary"
                                            data-action="duplicate-model"
                                            data-model-id="<?php p($model['id']); ?>"
                                            aria-label="<?php p($l->t('Copy this work schedule')); ?>"
                                            title="<?php p($l->t('Create a copy of this work schedule as a starting point for a new one')); ?>">
                                        <?php p($l->t('Copy')); ?>
                                    </button>
                                    <button type="button" 
                                            class="btn btn--sm btn--secondary" 
                                            data-action="edit-model" 
                                            data-model-id="<?php p($model['id']); ?>"
                                            aria-label="<?php p($l->t('Edit this work schedule')); ?>"
                                            title="<?php p($l->t('Click to change the working hours or name of this work schedule')); ?>">
                                        <?php p($l->t('Edit')); ?>
                                    </button>
                                    <button type="button" 
                                            class="btn btn--sm btn--danger" 
                                            data-action="delete-model" 
                                            data-model-id="<?php p($model['id']); ?>"
                                            aria-label="<?php p($l->t('Delete this work schedule')); ?>"
                                            title="<?php p($l->t('Click to delete this work schedule. This cannot be undone, so make sure no employees are using it first.')); ?>">
                                        <?php p($l->t('Delete')); ?>
                                    </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>
            </div><!-- /.azc-card__body -->
        </section><!-- /.azc-card -->
<!-- Initialize JavaScript -->
<script nonce="<?php p($_['cspNonce'] ?? ''); ?>">
    window.ArbeitszeitCheck = window.ArbeitszeitCheck || {};
    window.ArbeitszeitCheck.l10n = window.ArbeitszeitCheck.l10n || {};
    window.ArbeitszeitCheck.l10n.confirmDeleteModel = <?php echo json_encode($l->t("Are you sure you want to delete this work schedule?\n\nThis will permanently remove this schedule. If any employees are using this schedule, you should assign them to a different schedule first.\n\nThis action cannot be undone."), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.confirmDeleteModelWithName = <?php echo json_encode($l->t("Are you sure you want to delete \"{name}\"?\n\nThis will permanently remove this work schedule. If any employees are using this schedule, you should assign them to a different schedule first.\n\nThis action cannot be undone."), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.error = <?php echo json_encode($l->t('An error occurred'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.createModel = <?php echo json_encode($l->t('Create Working Time Model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.editModel = <?php echo json_encode($l->t('Edit Working Time Model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.create = <?php echo json_encode($l->t('Create'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.save = <?php echo json_encode($l->t('Save'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.cancel = <?php echo json_encode($l->t('Cancel'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.name = <?php echo json_encode($l->t('Name'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.description = <?php echo json_encode($l->t('Description'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.descriptionOptional = <?php echo json_encode($l->t('Optional description'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.editorLead = <?php echo json_encode($l->t('Name the schedule, set hours, and optionally fill weekday times. Cancel returns to the list.'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.type = <?php echo json_encode($l->t('Type'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.weeklyHours = <?php echo json_encode($l->t('Weekly Hours'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.dailyHours = <?php echo json_encode($l->t('Daily Hours'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.workDaysPerWeek = <?php echo json_encode($l->t('Work days per week'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.isDefault = <?php echo json_encode($l->t('Set as Default'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.fullTime = <?php echo json_encode($l->t('Full-Time'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.partTime = <?php echo json_encode($l->t('Part-Time'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.flexible = <?php echo json_encode($l->t('Flexible'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.trustBased = <?php echo json_encode($l->t('Trust-Based'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.shiftWork = <?php echo json_encode($l->t('Shift Work'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.modelNameHelp = <?php echo json_encode($l->t('Enter a name for this work schedule (e.g., "Full-Time", "Part-Time")'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.weeklyHoursHelp = <?php echo json_encode($l->t('Decimal hours are allowed (e.g. 38.7 h/week under a collective agreement). Overtime targets use this weekly total spread across your working days.'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.dailyHoursHelp = <?php echo json_encode($l->t('Usual hours per workday (e.g. 7.74 if 38.7 h/week over five days). Overtime compares worked time to the weekly contract hours × (working days ÷ 5).'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.workDaysPerWeekHelp = <?php echo json_encode($l->t('Typical number of work days each week for this model (e.g. 4 for a four-day week). Used for model-based vacation entitlement calculations.'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.modelCreated = <?php echo json_encode($l->t('Model created successfully'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.modelUpdated = <?php echo json_encode($l->t('Model updated successfully'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.failedToLoadModel = <?php echo json_encode($l->t('Failed to load model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.invalidModelData = <?php echo json_encode($l->t('Invalid model data'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.failedToCreateModel = <?php echo json_encode($l->t('Failed to create model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.failedToUpdateModel = <?php echo json_encode($l->t('Failed to update model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.failedToDeleteModel = <?php echo json_encode($l->t('Failed to delete model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.modelDeleted = <?php echo json_encode($l->t('Working time model deleted successfully'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.modelCopied = <?php echo json_encode($l->t('Model copied successfully'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.failedToCopyModel = <?php echo json_encode($l->t('Failed to copy model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.copySuffix = <?php echo json_encode($l->t('Copy'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.copyNoun = <?php echo json_encode($l->t('Copy (noun)'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.copyModelTitle = <?php echo json_encode($l->t('Copy Working Time Model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.copy = <?php echo json_encode($l->t('Copy'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.sourceModel = <?php echo json_encode($l->t('Source model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.deleteModelTitle = <?php echo json_encode($l->t('Delete working time model'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.delete = <?php echo json_encode($l->t('Delete'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    window.ArbeitszeitCheck.l10n.thisWorkSchedule = <?php echo json_encode($l->t('this work schedule'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
</script>

</div><!-- /.azc-page-stack -->
<?php include __DIR__ . '/common/page-end.php'; ?>
