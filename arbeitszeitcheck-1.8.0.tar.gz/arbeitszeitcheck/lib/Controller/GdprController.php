<?php

declare(strict_types=1);

/**
 * GDPR controller for the arbeitszeitcheck app
 *
 * @copyright Copyright (c) 2024, Nextcloud GmbH
 * @license AGPL-3.0-or-later
 */

namespace OCA\ArbeitszeitCheck\Controller;

use OCA\ArbeitszeitCheck\Db\TimeEntryMapper;
use OCA\ArbeitszeitCheck\Db\AbsenceMapper;
use OCA\ArbeitszeitCheck\Db\UserSettingsMapper;
use OCA\ArbeitszeitCheck\Db\ComplianceViolationMapper;
use OCA\ArbeitszeitCheck\Db\AuditLogMapper;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Db\TTransactional;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\AppFramework\Http\DataDownloadResponse;
use OCP\AppFramework\Http\JSONResponse;
use OCP\AppFramework\Http\Response;
use OCP\IConfig;
use OCP\IDBConnection;
use OCP\IRequest;
use OCP\IUserSession;
use OCP\IL10N;

/**
 * GdprController
 */
class GdprController extends Controller
{
	use TTransactional;

	private TimeEntryMapper $timeEntryMapper;
	private AbsenceMapper $absenceMapper;
	private UserSettingsMapper $userSettingsMapper;
	private ComplianceViolationMapper $violationMapper;
	private AuditLogMapper $auditLogMapper;
	private IUserSession $userSession;
	private IL10N $l10n;
	private IConfig $config;
	private IDBConnection $db;

	public function __construct(
		string $appName,
		IRequest $request,
		TimeEntryMapper $timeEntryMapper,
		AbsenceMapper $absenceMapper,
		UserSettingsMapper $userSettingsMapper,
		ComplianceViolationMapper $violationMapper,
		AuditLogMapper $auditLogMapper,
		IUserSession $userSession,
		IL10N $l10n,
		IConfig $config,
		IDBConnection $db
	) {
		parent::__construct($appName, $request);
		$this->timeEntryMapper = $timeEntryMapper;
		$this->absenceMapper = $absenceMapper;
		$this->userSettingsMapper = $userSettingsMapper;
		$this->violationMapper = $violationMapper;
		$this->auditLogMapper = $auditLogMapper;
		$this->userSession = $userSession;
		$this->l10n = $l10n;
		$this->config = $config;
		$this->db = $db;
	}

	/**
	 * Export all user data for GDPR compliance (Art. 15 GDPR - Right to access)
	 * NoCSRFRequired: GET download is often opened via direct link (e.g. from settings); user must be logged in.
	 */
	#[NoAdminRequired]
	#[NoCSRFRequired]
	public function export(): Response
	{
		try {
			$user = $this->userSession->getUser();
			if (!$user) {
				return new JSONResponse([
					'success' => false,
					'error' => $this->l10n->t('User not authenticated'),
				], Http::STATUS_UNAUTHORIZED);
			}

			$userId = $user->getUID();

		// Collect all user data from database
		$allTimeEntries = $this->timeEntryMapper->findByUser($userId);
		$allAbsences = $this->absenceMapper->findByUser($userId);
		$allSettings = $this->userSettingsMapper->getUserSettings($userId);
		$allViolations = $this->violationMapper->findByUser($userId);
		$allAuditLogs = $this->auditLogMapper->findByUser($userId);

		// Convert entities to arrays for JSON export
		$timeEntriesData = [];
		foreach ($allTimeEntries as $entry) {
			try {
				$timeEntriesData[] = $entry->getSummary();
			} catch (\Throwable $e) {
				\OCP\Log\logger('arbeitszeitcheck')->error('Error getting summary for time entry ' . $entry->getId() . ' in GDPR export: ' . $e->getMessage(), ["exception" => $e]);
				continue;
			}
		}

		$absencesData = [];
		foreach ($allAbsences as $absence) {
			try {
				$startDate = $absence->getStartDate();
				$endDate = $absence->getEndDate();
				$absencesData[] = [
					'id' => $absence->getId(),
					'type' => $absence->getType(),
					'start_date' => $startDate ? $startDate->format('c') : null,
					'end_date' => $endDate ? $endDate->format('c') : null,
					'days' => $absence->getDays(),
					'reason' => $absence->getReason(),
					'status' => $absence->getStatus(),
					'approver_comment' => $absence->getApproverComment(),
					'approved_at' => $absence->getApprovedAt() ? $absence->getApprovedAt()->format('c') : null,
					'created_at' => ($createdAt = $absence->getCreatedAt()) ? $createdAt->format('c') : null,
					'updated_at' => ($updatedAt = $absence->getUpdatedAt()) ? $updatedAt->format('c') : null
				];
			} catch (\Throwable $e) {
				\OCP\Log\logger('arbeitszeitcheck')->error('Error processing absence ' . $absence->getId() . ' in GDPR export: ' . $e->getMessage(), ["exception" => $e]);
				continue;
			}
		}

		$settingsData = [];
		foreach ($allSettings as $setting) {
			try {
				$createdAt = $setting->getCreatedAt();
				$updatedAt = $setting->getUpdatedAt();
				$settingsData[] = [
					'setting_key' => $setting->getSettingKey(),
					'setting_value' => $setting->getSettingValue(),
					'created_at' => $createdAt ? $createdAt->format('c') : null,
					'updated_at' => $updatedAt ? $updatedAt->format('c') : null
				];
			} catch (\Throwable $e) {
				\OCP\Log\logger('arbeitszeitcheck')->error('Error processing setting in GDPR export: ' . $e->getMessage(), ["exception" => $e]);
				continue;
			}
		}

		$violationsData = [];
		foreach ($allViolations as $violation) {
			try {
				$date = $violation->getDate();
				$createdAt = $violation->getCreatedAt();
				$violationsData[] = [
					'id' => $violation->getId(),
					'violation_type' => $violation->getViolationType(),
					'description' => $violation->getDescription(),
					'date' => $date ? $date->format('c') : null,
					'time_entry_id' => $violation->getTimeEntryId(),
					'severity' => $violation->getSeverity(),
					'resolved' => $violation->getResolved(),
					'resolved_at' => $violation->getResolvedAt() ? $violation->getResolvedAt()->format('c') : null,
					'created_at' => $createdAt ? $createdAt->format('c') : null
				];
			} catch (\Throwable $e) {
				\OCP\Log\logger('arbeitszeitcheck')->error('Error processing violation ' . $violation->getId() . ' in GDPR export: ' . $e->getMessage(), ["exception" => $e]);
				continue;
			}
		}

		$auditLogsData = [];
		foreach ($allAuditLogs as $log) {
			try {
				// Decode JSON values if present
				$oldValues = $log->getOldValues();
				$newValues = $log->getNewValues();

				if ($oldValues !== null) {
					$decoded = json_decode($oldValues, true);
					$oldValues = $decoded !== null ? $decoded : $oldValues;
				}

				if ($newValues !== null) {
					$decoded = json_decode($newValues, true);
					$newValues = $decoded !== null ? $decoded : $newValues;
				}

				$createdAt = $log->getCreatedAt();
				$auditLogsData[] = [
					'id' => $log->getId(),
					'action' => $log->getAction(),
					'entity_type' => $log->getEntityType(),
					'entity_id' => $log->getEntityId(),
					'old_values' => $oldValues,
					'new_values' => $newValues,
					'ip_address' => $log->getIpAddress(),
					'user_agent' => $log->getUserAgent(),
					'performed_by' => $log->getPerformedBy(),
					'created_at' => $createdAt ? $createdAt->format('c') : null
				];
			} catch (\Throwable $e) {
				\OCP\Log\logger('arbeitszeitcheck')->error('Error processing audit log ' . $log->getId() . ' in GDPR export: ' . $e->getMessage(), ["exception" => $e]);
				continue;
			}
		}

		// Compile complete export data
		$data = [
			'export_metadata' => [
				'user_id' => $userId,
				'export_date' => date('c'),
				'export_reason' => 'GDPR Article 15 - Right to access',
				'app_version' => '1.0.0'
			],
			'time_entries' => $timeEntriesData,
			'absences' => $absencesData,
			'user_settings' => $settingsData,
			'compliance_violations' => $violationsData,
			'audit_logs' => $auditLogsData,
			'data_summary' => [
				'total_time_entries' => count($timeEntriesData),
				'total_absences' => count($absencesData),
				'total_settings' => count($settingsData),
				'total_violations' => count($violationsData),
				'total_audit_logs' => count($auditLogsData)
			]
		];

			$json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

			if ($json === false) {
				throw new \Exception($this->l10n->t('Failed to encode data as JSON'));
			}

			$filename = 'arbeitszeitcheck-gdpr-export-' . $userId . '-' . date('Y-m-d') . '.json';

			return new DataDownloadResponse($json, $filename, 'application/json; charset=utf-8');
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Error in GdprController::export: ' . $e->getMessage(), ["exception" => $e]);
			return new JSONResponse([
				'success' => false,
				'error' => $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.')
			], Http::STATUS_INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Delete all user data (GDPR Art. 17 - Right to erasure)
	 *
	 * Server-side checks (the client also shows a destructive confirmDialog):
	 *  - Authenticated session is required.
	 *  - CSRF protection via the default Nextcloud requesttoken (no NoCSRFRequired).
	 *  - Legal retention period (configurable, default 2 years per German labor law)
	 *    is enforced server-side and cannot be bypassed by the caller.
	 *  - Any reason text supplied by the client is recorded verbatim (truncated)
	 *    in the audit log together with the IP / user agent for accountability.
	 *
	 * The controller responds with a deterministic summary so the UI can show
	 * exactly which data was removed and which had to be retained.
	 */
	#[NoAdminRequired]
	public function delete(): JSONResponse
	{
		try {
			$user = $this->userSession->getUser();
			if (!$user) {
				return new JSONResponse([
					'success' => false,
					'error' => $this->l10n->t('User not authenticated'),
				], Http::STATUS_UNAUTHORIZED);
			}

			$userId = $user->getUID();
			$now = new \DateTime();

			// Capture the user-supplied reason (free-text) for the audit log. We never
			// trust the client to enforce its presence; we only persist what was sent.
			$rawReason = $this->request->getParam('reason', null);
			if (!is_string($rawReason)) {
				$rawReason = '';
			}
			$reason = trim($rawReason);
			if ($reason === '') {
				$reason = 'user_request';
			}
			if (mb_strlen($reason) > 500) {
				$reason = mb_substr($reason, 0, 500);
			}

			// Use admin-configured retention period (default 2 years; German labor law minimum)
			$retentionYears = max(1, min(10, (int)$this->config->getAppValue('arbeitszeitcheck', 'retention_period', '2')));
			$retentionDate = clone $now;
			$retentionDate->modify('-' . $retentionYears . ' years');

			// Get all time entries for user first
			$allTimeEntries = $this->timeEntryMapper->findByUser($userId);

			// Separate entries by retention period
			$oldTimeEntries = array_filter($allTimeEntries, function ($entry) use ($retentionDate) {
				return $entry->getStartTime() < $retentionDate;
			});

			$recentEntries = array_filter($allTimeEntries, function ($entry) use ($retentionDate) {
				return $entry->getStartTime() >= $retentionDate;
			});
			$retainedCount = count($recentEntries);

			$userSettings = $this->userSettingsMapper->getUserSettings($userId);

			// Atomic wipe: either all eligible rows + settings + audit land, or none.
			$deletedCount = $this->atomic(function () use ($oldTimeEntries, $userId, $userSettings, $retainedCount, $retentionYears, $now, $reason): int {
				$count = 0;
				foreach ($oldTimeEntries as $entry) {
					$this->timeEntryMapper->delete($entry);
					$count++;
				}
				foreach ($userSettings as $setting) {
					$this->userSettingsMapper->deleteSetting($userId, $setting->getSettingKey());
				}
				// Note: absences, violations, and audit logs are retained for legal compliance.
				$this->auditLogMapper->logAction(
					$userId,
					'gdpr_data_deletion_request',
					'user',
					null,
					null,
					[
						'deleted_time_entries' => $count,
						'retained_time_entries' => $retainedCount,
						'retention_period_years' => $retentionYears,
						'request_date' => $now->format('c'),
						'reason' => $reason,
					]
				);
				return $count;
			}, $this->db);

			$message = $this->l10n->n(
				'Data deletion request processed. %1$d time entry deleted. %2$d entries retained due to %3$d-year retention requirement.',
				'Data deletion request processed. %1$d time entries deleted. %2$d entries retained due to %3$d-year retention requirement.',
				$deletedCount,
				[$deletedCount, $retainedCount, $retentionYears]
			);

			return new JSONResponse([
				'success' => true,
				'message' => $message,
				'deleted_entries' => $deletedCount,
				'retained_entries' => $retainedCount,
				'retention_period' => $retentionYears . ' ' . $this->l10n->n('year', 'years', $retentionYears),
				'note' => $this->l10n->t('Some data must be retained per configured retention period. Absences, audit logs, and compliance violations are retained for legal compliance purposes.')
			]);
		} catch (\Throwable $e) {
			\OCP\Log\logger('arbeitszeitcheck')->error('Error in GdprController::delete: ' . $e->getMessage(), ['exception' => $e]);
			return new JSONResponse([
				'success' => false,
				'error' => $this->l10n->t('An unexpected error occurred. Please try again. If the problem continues, contact your administrator.')
			], Http::STATUS_INTERNAL_SERVER_ERROR);
		}
	}
}
